import torch
import torch.nn as nn
import torch.nn.functional as F
import math

from config.transformer_config import TransformerConfig
from config.train_config import TrainConfig

from .multi_self_decoder import MultiSelfDecoder
from src.feedforward import FeedForward
from src.add_and_norm import AddNorm

class Decoder(nn.Module):
  #multi-attention -- > add and norm --> feed forward --> add and norm
  def __init__(self, config: TransformerConfig):
    super().__init__()
    self.ma_self = MultiSelfDecoder(config)
    self.ff = FeedForward(config)
    self.an = AddNorm(config)
    self.res1 = nn.Dropout(p=config.dropout)
    self.res2 = nn.Dropout(p=config.dropout)
    
  def forward(self,y):
    out1 = self.ma_self(y)
    out2 = self.res1(out1)
    out3 = self.an(out1,out2)
    out4 = self.ff(out3)
    out5 = self.res2(out4)
    out6 = self.an(out3,out5)
    return out6